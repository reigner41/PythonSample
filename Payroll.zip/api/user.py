import json
from controller.blog import *

class UserApi:
    def getUser():
        return "getUser"